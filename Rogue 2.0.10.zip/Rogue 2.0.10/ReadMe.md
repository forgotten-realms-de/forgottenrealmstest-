# Made by HulkDoesGaming - Ravenstone Resources.

# Rogue Theme for NamelessMC

# Installation:
- Note: Make sure you have NamelessMC version v2! NamelessMC v1 will NOT work!
- Unzip the file and upload the contents of the "upload" file straight into your main NamelessMC installation directory (where the folders core, custom, modules, uploads, cache are)
- Head over to StaffCP -> Templates, click the "Install" button
- Enable the "Rogue" template by clicking the "Activate" button, and make it default by clicking the "Make Default" button
- You're done! Configure the template at StaffCP -> Layout -> Templates -> Rogue (settings button)

# Discord: 
https://discord.gg/UKsRhgXQ

# 091728IZLXYI4YAP2YZKL0M